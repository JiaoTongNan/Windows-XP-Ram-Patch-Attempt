#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "Header.h"
#include "windows.h"

using namespace std;

//To do
//1. prompt
//2. option yes or no
//3A. if yes, install ram patch
//3B. if no, exit
//**3C. Backup
//**3D. Restore
//4A. Get location of drivers. Copy new driver files there
//5A. Add \pae on boot.ini's final line (may require copying the file and adding input last
//6A. If successful, then success. If fail, then fail.

/*		NOTE:
This program assumes the user did NOT set a custom
Windows directory folder!
*/

int main()
{
	//constant
	const string DRIVER_DIRECTORY = "\\WINDOWS\\system32";
	const string BOOT_DIRECTORY = "\\WINDOWS\\system32\\drivers\\boot.ini";
	const string ENABLE_PAE = "\\PAE";
	const string DEFAULT_INSTALLATION = "C:";

	//variables
	//in the future, the program will not assume the installation is C:, if this patch is applied
	string computer_directory = "\0";
	string* temp_directory;
	temp_directory = &computer_directory;
	string absoluteBootDirectory = "\0";
	string absoluteInstallationDirect = "\0";
	bool is_windows_xp = true; //make sure OS version is Windows XP! Close if on any other version to prevent breaking something!!
	char input = '\0';
	int ASCII_VALUE = 0;
	
	//PROCESS
	cout << "Welcome to Diyba's 128gb Windows XP Ram Patch!" << endl;
	cout << "Please select an option!" << endl;
	cout << endl;
	cout << setw(10) << "Install (I)";
	cout << setw(10) << "Exit (E)";
	cout << endl;

	cin.get(input);
	ASCII_VALUE = toupper(input);

	isValidInput(ASCII_VALUE);

	absoluteInstallationDirect = getInstallationDirectory();
	computer_directory = getCurrentDirectory();
	backupBootIni(computer_directory);

	//back up old driver files and boot.ini
	//CopyFile()
	//copy driver files to drivers
	//

}