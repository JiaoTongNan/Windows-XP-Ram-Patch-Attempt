#pragma once
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

//This includes commands

//If program input is valid
//If equal to 'I' or 'E,' then the program continues

void isValidInput(int ASCII_VALUE);

string getInstallationDirectory();

string getCurrentDirectory();

void backupDrivers();

void CreateFolder(const char* path);

void backupBootIni(std::string currentDirectory);

void copyFiles();

void restoreFiles();

void restoreBoot();

bool isWindowsXP();