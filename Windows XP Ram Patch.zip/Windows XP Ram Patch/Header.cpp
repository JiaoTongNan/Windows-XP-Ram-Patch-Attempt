#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include "windows.h"
#include "stdio.h"
//#include "filesystem"
#include "direct.h"

using namespace std;

void isValidInput(int ASCII_VALUE)
{
	int* input;
	input = &ASCII_VALUE;
	char temp = '\0';

	while (static_cast<char>(*input) != 'E' && static_cast<char>(*input != 'I'))
	{
		cout << "Invalid input, please type \"I\" (install)  or \"E\" (exit). " << "\n";
		cin >> temp;
		*input = toupper(static_cast<char>(temp));
	}

	if (ASCII_VALUE == 'E')
	{
		exit(1);
	}
}

string getInstallationDirectory()
{
	//Code by 123iamking from stack overflow
	//grabs only the directory letter and colon
	TCHAR szDir[MAX_PATH] = { 0 };
	GetModuleFileName(NULL, szDir, MAX_PATH);
	szDir[string(szDir).find_first_of("\\/")] = 0;

	return szDir;
}

string getCurrentDirectory()
{
	string currentDirectory = "\0";
	//from Raxvan from stack overflow
	char currentPath[MAX_PATH];
	GetCurrentDirectoryA(MAX_PATH, currentPath);

	//for each loop to get the directory
	for (auto& row : currentPath)
	{
			currentDirectory = currentPath;
	}

	return currentDirectory;
}

//credit to Fivee Arch from stack overflow

void CreateFolder(const char* path)
{
	if (!CreateDirectory(path, NULL))
	{
		return;
	}
}

void backupBootIni(string currentDirectory)
{
	//create new folder
	//String has to be converted to char in order to do this
	string temp = "\\bootBackUp";
	string newDirect = currentDirectory + temp;

	//make a new folder in executable location
	//CreateDirectoryA(newDirectName);
	
	//CreateFolder(newDirect);

	//backup files and save to program files

}

void backupDrivers()
{
}

void copyFiles()
{
}

void restoreFiles()
{
}

void restoreBoot()
{
}

bool isWindowsXP()
{
	return true;
}